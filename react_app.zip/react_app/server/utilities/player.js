class Player {
    constructor(name, room, id, piece='') {
        this.name = name
        this.room = room
        this.id = id
        this.piece = piece
    }
}

module.exports = Player