import Header from "./Components/Header/Header";
import Main from "./Components/Main/Main";
import Footer from "./Components/Footer/Footer";
import JoinRoomModal from "./Components/JoinRoomModal/JoinRoomModal";
import { useEffect, useState } from "react";
import io from "socket.io-client";
import Login from './Components/LoginPage';
import Home from './Components/HomePage';
import firebase  from './services/firebase';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';

const socket = io.connect("http://localhost:8000");

function App() {
  const [user, setUser] = useState(null);
  
    useEffect(() => {
      firebase.auth().onAuthStateChanged(user => {
        setUser(user);
      })
    }, [])
  const [showModal, setShowModal] = useState(false);
  const [roomCode, setRoomCode] = useState(null);

  useEffect(() => {
    console.log(roomCode);
    if (roomCode) {
      socket.emit("joinRoom", roomCode);
    }
  }, [roomCode]);

  return (
    <>
      <JoinRoomModal
        showModal={showModal}
        setShowModal={setShowModal}
        setRoomCode={setRoomCode}
      />
      <Header />
      <Main socket={socket} roomCode={roomCode} />
      <Footer setShowModal={setShowModal} />
      <div className="game">
        {user ? <Home user={user} /> : <Login/>}
      </div>
    </>
  );
}

export default App;
