import "./Header.css";

const Header = () => {
  return (
    <header>
      <h1 className="header-title">Tic Tac Toe 1vs1</h1>
    </header>
  );
};

export default Header;
