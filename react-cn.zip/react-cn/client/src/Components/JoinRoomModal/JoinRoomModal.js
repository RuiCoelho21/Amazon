import "./JoinRoomModal.css";
import { motion } from "framer-motion";
import { useState } from "react";

const backgrop = {
  visible: { opacity: 1 },
  hidden: { opacity: 0 },
};

const modal = {
  hidden: {
    y: "-10vh",
    opacity: 0,
  },

  visible: {
    y: "00px",
    opacity: 1,
    transition: {
      delay: 0,
    },
  },
};

const JoinRoomModal = ({ showModal, setShowModal, setRoomCode }) => {
  const [roomCodeInput, setRoomCodeInput] = useState(null);
  const handleSave = () => {
    setShowModal(false);
    setRoomCode(roomCodeInput);
  };

  return (
    <>
      {showModal && (
        <motion.div
          className="joinRoomModal-container"
          variants={backgrop}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.div className="joinRoomModal-card" variants={modal}>
            <h1 className="joinRoomModal-card-title">Room ID</h1>
            <input
              className="joinRoomModal-card-input"
              type="number"
              placeholder="Your ID"
              onChange={(e) => setRoomCodeInput(e.target.value)}
            />
            <button onClick={handleSave} className="joinRoomModal-card-button">
              Go!
            </button>
          </motion.div>
        </motion.div>
      )}
    </>
  );
};

export default JoinRoomModal;
