## Steps

1. Update Firebase Configurations

2. npm install

3. npm start
