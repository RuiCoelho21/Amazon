import { useState, useEffect } from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom'

import Login from './components/LoginPage';
import Home from './components/HomePage';
import firebase  from './services/firebase';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Game() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    firebase.auth().onAuthStateChanged(user => {
      setUser(user);
    })
  }, [])

  return (
    <Router>
    <div className="game">
      {user ? <Home user={user} /> : <Login/>}
    </div>
    </Router>
  );
}

export default Game;